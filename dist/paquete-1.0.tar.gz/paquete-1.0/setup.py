from setuptools import setup
setup(
    name = "paquete",
    version = "1.0",
    description= "segunda pre entrega",
    author="Ezequiel Carnet",
    author_email="ezequielcarnet@hmail.com",
    packages=["Paquete"]
    )

